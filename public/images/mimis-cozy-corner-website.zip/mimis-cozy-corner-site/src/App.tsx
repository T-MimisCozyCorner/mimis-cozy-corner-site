import { Link, useLocation } from 'wouter'
import { ArrowRight, BadgeDollarSign, Bot, BriefcaseBusiness, Check, ChevronRight, House, Menu, Search, ShoppingBag, Sparkles, X, PenLine, Download, Mail, Instagram, Facebook } from 'lucide-react'
import { useState } from 'react'
import avatar from './assets/mimi-avatar.png'
import creativeAdsLogo from './assets/mimis-creative-ads-logo.png'
import laTambora from './assets/la-tambora-sample.jpg'

const branches = [
  { slug: 'creative-ads', icon: Sparkles, title: "Mimi's Creative Ads", tag: 'Services', desc: 'Scroll-stopping social-media ads for small businesses, starting at $25.', color: 'pink', cta: 'Get an Ad' },
  { slug: 'finds', icon: Search, title: 'Mimi Finds Daily', tag: 'Finds', desc: 'Useful products, deals, and everyday finds worth checking out.', color: 'cyan', cta: 'See Finds' },
  { slug: 'bullet-point-boutique', icon: PenLine, title: "Mimi's Bullet Point Boutique", tag: 'Amazon Copy', desc: 'Product titles, bullets, descriptions, and listing copy built to make shoppers care.', color: 'purple', cta: 'Explore Copy' },
  { slug: 'housing-help', icon: House, title: 'Housing Help Hub', tag: 'Resources', desc: 'Practical housing guides, tools, and digital resources designed to make the process easier to navigate.', color: 'blue', cta: 'Explore Housing' },
  { slug: 'ai', icon: Bot, title: "Mimi's AI Corner", tag: 'AI Tools', desc: 'Prompt packs, AI organizers, business tools, and practical ways to use AI.', color: 'teal', cta: 'Explore AI' },
  { slug: 'digital-products', icon: Download, title: 'Digital Products', tag: 'Shop', desc: 'Ebooks, planners, printables, prompt packs, and downloadable creative tools.', color: 'gold', cta: 'Shop Digital' },
]

function Header() {
  const [open, setOpen] = useState(false)
  const [location] = useLocation()
  const nav = [
    ['/', 'Home'],
    ['/creative-ads', 'Creative Ads'],
    ['/finds', 'Finds Daily'],
    ['/digital-products', 'Digital Products'],
    ['/about', 'About'],
  ]
  return <header className="site-header">
    <div className="container nav-wrap">
      <Link href="/" className="brand" onClick={() => setOpen(false)}>
        <span className="brand-mark">M</span>
        <span><strong>Mimi's</strong><small>Cozy Corner</small></span>
      </Link>
      <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
      <nav className={open ? 'nav open' : 'nav'}>
        {nav.map(([href, label]) => <Link key={href} href={href} className={location === href ? 'active' : ''} onClick={() => setOpen(false)}>{label}</Link>)}
        <Link href="/contact" className="nav-cta" onClick={() => setOpen(false)}>Work With Mimi <ArrowRight size={16}/></Link>
      </nav>
    </div>
  </header>
}

function Hero() {
  return <section className="hero">
    <div className="hero-glow glow-a"/><div className="hero-glow glow-b"/>
    <div className="container hero-grid">
      <div className="hero-copy">
        <div className="eyebrow"><Sparkles size={15}/> ONE CORNER. A WHOLE LOT OF CREATIVITY.</div>
        <h1>Ideas that look good <span>and do something.</span></h1>
        <p className="hero-text">Welcome to Mimi's Cozy Corner — a creative home for small-business advertising, digital products, useful finds, AI tools, Amazon copy, and practical resources.</p>
        <div className="hero-actions"><Link className="button primary" href="/creative-ads">Start With Creative Ads <ArrowRight size={18}/></Link><Link className="button ghost" href="#branches">Explore Mimi's Corner</Link></div>
        <div className="trust-row"><span><Check size={15}/> Small-business focused</span><span><Check size={15}/> Digital-first</span><span><Check size={15}/> Built to be useful</span></div>
      </div>
      <div className="hero-art">
        <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
        <div className="avatar-card"><img src={avatar} alt="Mimi avatar"/><div className="avatar-chip"><Sparkles size={15}/> Creative mind at work</div></div>
        <div className="floating-card card-top"><BadgeDollarSign/><div><b>$25</b><small>starter ads</small></div></div>
        <div className="floating-card card-bottom"><BriefcaseBusiness/><div><b>6+ branches</b><small>one creative home</small></div></div>
      </div>
    </div>
  </section>
}

function BranchCard({ b }: { b: typeof branches[number] }) {
  const Icon = b.icon
  return <article className={`branch-card ${b.color}`}>
    <div className="branch-icon"><Icon size={24}/></div>
    <div className="tag">{b.tag}</div>
    <h3>{b.title}</h3>
    <p>{b.desc}</p>
    <Link href={`/${b.slug}`} className="text-link">{b.cta} <ChevronRight size={17}/></Link>
  </article>
}

function Home() {
  return <>
    <Header/><main>
      <Hero/>
      <section className="section" id="branches">
        <div className="container">
          <div className="section-heading"><div><div className="eyebrow">THE MIMI'S ECOSYSTEM</div><h2>Pick your corner.</h2></div><p>Different needs. Same creative energy. Each branch has a clear job, and they all live under one roof.</p></div>
          <div className="branch-grid">{branches.map(b => <BranchCard key={b.slug} b={b}/>)}</div>
        </div>
      </section>
      <section className="feature-section">
        <div className="container feature-grid">
          <div className="feature-copy"><div className="eyebrow">FEATURED SERVICE</div><h2>Make your business impossible to scroll past.</h2><p>Mimi's Creative Ads creates custom social-media graphics and copy for small businesses that need to look professional without paying agency prices.</p><ul><li><Check/> Custom design matched to your business</li><li><Check/> Persuasive caption + call to action</li><li><Check/> QR codes, contact details, and brand elements</li><li><Check/> Starter pricing from <strong>$25</strong></li></ul><Link className="button primary" href="/creative-ads">See the $25 service <ArrowRight size={18}/></Link></div>
          <div className="feature-image"><img src={creativeAdsLogo} alt="Mimi's Creative Ads logo"/></div>
        </div>
      </section>
      <section className="sample-section">
        <div className="container sample-grid"><div><div className="eyebrow">PORTFOLIO SAMPLE</div><h2>Real example. Real small business.</h2><p>This La Tambora advertisement is an example of the type of promotional creative Mimi's Creative Ads can make for a local business.</p><Link className="button ghost-light" href="/creative-ads">See Creative Ads <ArrowRight size={18}/></Link></div><div className="sample-frame"><img src={laTambora} alt="La Tambora promotional advertisement example"/></div></div>
      </section>
      <section className="about-strip"><div className="container about-grid"><img src={avatar} alt="Mimi avatar"/><div><div className="eyebrow">MEET MIMI</div><h2>One person. A bunch of ideas. A cozy corner to put them.</h2><p>Mimi's Cozy Corner brings creative services, digital products, helpful resources, and practical online ideas together so customers don't have to hunt through a dozen different places.</p><Link className="text-link" href="/about">Meet Mimi <ChevronRight size={17}/></Link></div></div></section>
    </main><Footer/>
  </>
}

function CreativeAds() {
  return <><Header/><main><section className="page-hero pink-bg"><div className="container page-hero-grid"><div><div className="eyebrow">MIMI'S CREATIVE ADS</div><h1>Give your business a post people actually notice.</h1><p>Custom social-media advertisements for small businesses — designed to look professional, communicate fast, and give customers a reason to stop scrolling.</p><div className="price-pill">Starting at <strong>$25</strong></div><Link className="button primary" href="/contact">Get My Ad <ArrowRight size={18}/></Link></div><img src={creativeAdsLogo} alt="Mimi's Creative Ads logo"/></div></section><section className="section"><div className="container"><div className="section-heading"><div><div className="eyebrow">HOW IT WORKS</div><h2>Simple. Custom. Ready to post.</h2></div></div><div className="steps"><div><b>01</b><h3>Send your info</h3><p>Business name, logo, photos, offer, contact info, and anything customers need to know.</p></div><div><b>02</b><h3>I build the ad</h3><p>Design + promotional copy are created around your business and the action you want customers to take.</p></div><div><b>03</b><h3>You post it</h3><p>Use the finished graphic and caption on Facebook, Instagram, TikTok, Pinterest, or wherever your customers are.</p></div></div></div></section><section className="sample-section light"><div className="container sample-grid"><div><div className="eyebrow">PORTFOLIO</div><h2>La Tambora sample</h2><p>A food-business promotional post built around authentic branding, a strong visual, QR code, and a clear promotional message.</p><Link className="button primary" href="/contact">Create One For My Business</Link></div><div className="sample-frame"><img src={laTambora} alt="La Tambora advertisement sample"/></div></div></section></main><Footer/></>
}

function BranchPage({ branch }: { branch: typeof branches[number] }) {
  const Icon = branch.icon
  return <><Header/><main><section className={`page-hero ${branch.color}-bg`}><div className="container simple-page"><div className="branch-icon large"><Icon size={34}/></div><div className="eyebrow">{branch.tag}</div><h1>{branch.title}</h1><p>{branch.desc}</p><Link className="button primary" href="/contact">Let's Build This <ArrowRight size={18}/></Link></div></section><section className="section"><div className="container content-card"><h2>This corner is growing.</h2><p>I'm building this section into a useful destination with clear offers, helpful content, and products people can actually use. Check back as new resources are added.</p><div className="mini-features"><span><Check/> Practical</span><span><Check/> Affordable</span><span><Check/> Made with intention</span></div></div></section></main><Footer/></>
}

function About() { return <><Header/><main><section className="page-hero purple-bg"><div className="container about-page"><img src={avatar} alt="Mimi avatar"/><div><div className="eyebrow">ABOUT MIMI'S COZY CORNER</div><h1>Welcome to my little corner of the internet.</h1><p>Mimi's Cozy Corner is the umbrella for a collection of creative projects, services, digital products, finds, and resources. The goal is simple: make useful things, make them look good, and make them easier for real people to use.</p><p>From helping a small business turn its products into better copy to creating a $25 social-media ad, building digital tools, sharing useful finds, and creating practical housing resources — this corner is designed to keep growing.</p><Link className="button primary" href="/contact">Work With Mimi <ArrowRight size={18}/></Link></div></div></section></main><Footer/></> }

function Contact() { return <><Header/><main><section className="page-hero cyan-bg"><div className="container contact-page"><div><div className="eyebrow">LET'S WORK TOGETHER</div><h1>Have an idea? Let's make it real.</h1><p>Tell me which Mimi's corner you're interested in and what you need. For Creative Ads, include your business name, what you sell, your logo/photos, and your preferred contact details.</p></div><form className="contact-card" onSubmit={e => e.preventDefault()}><label>Name<input placeholder="Your name" /></label><label>Email<input type="email" placeholder="you@example.com" /></label><label>What do you need?<select defaultValue=""><option value="" disabled>Select a service</option><option>Mimi's Creative Ads</option><option>Mimi Finds Daily</option><option>Mimi's Bullet Point Boutique</option><option>Housing Help Hub</option><option>Mimi's AI Corner</option><option>Digital Products</option><option>Something else</option></select></label><label>Message<textarea rows={5} placeholder="Tell me what you're looking for..." /></label><button className="button primary" type="submit">Send Request <Mail size={18}/></button><small>Form setup can be connected to your preferred email/form service when you're ready to collect submissions.</small></form></div></section></main><Footer/></> }

function Footer() { return <footer><div className="container footer-grid"><div><Link href="/" className="brand"><span className="brand-mark">M</span><span><strong>Mimi's</strong><small>Cozy Corner</small></span></Link><p>Creative services, digital products, useful finds, and helpful resources — all in one cozy corner.</p></div><div><b>Explore</b><Link href="/creative-ads">Creative Ads</Link><Link href="/finds">Mimi Finds Daily</Link><Link href="/bullet-point-boutique">Bullet Point Boutique</Link><Link href="/digital-products">Digital Products</Link></div><div><b>More</b><Link href="/housing-help">Housing Help Hub</Link><Link href="/ai">AI Corner</Link><Link href="/about">About Mimi</Link><Link href="/contact">Contact</Link></div><div><b>Follow</b><a href="https://instagram.com/mimis_cozy_corner_co" target="_blank" rel="noreferrer"><Instagram size={17}/> Instagram</a><a href="https://facebook.com" target="_blank" rel="noreferrer"><Facebook size={17}/> Facebook</a></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} Mimi's Cozy Corner</span><span>Creative. Useful. A little cozy.</span></div></footer> }

export default function App() {
  return <Switch>
    <Route path="/"><Home/></Route>
    <Route path="/creative-ads"><CreativeAds/></Route>
    <Route path="/about"><About/></Route>
    <Route path="/contact"><Contact/></Route>
    {branches.filter(b => b.slug !== 'creative-ads').map(b => <Route key={b.slug} path={`/${b.slug}`}><BranchPage branch={b}/></Route>)}
    <Route><Home/></Route>
  </Switch>
}

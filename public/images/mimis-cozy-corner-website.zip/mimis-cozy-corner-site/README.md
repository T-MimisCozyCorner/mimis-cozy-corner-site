# Mimi's Cozy Corner — Website

Umbrella site for Mimi's Cozy Corner and its branches.

## Stack
- React + Vite + TypeScript
- Wouter for routing
- Lucide icons
- Cloudflare Pages deployment

## Routes
- `/` Home
- `/creative-ads`
- `/finds`
- `/bullet-point-boutique`
- `/housing-help`
- `/ai`
- `/digital-products`
- `/about`
- `/contact`

## Cloudflare Pages
Use:
- Production branch: `main`
- Build command: `npm run build`
- Build directory: `dist`

## Local development
```bash
npm install
npm run dev
```

## Build check
```bash
npm run build
```

## Custom domain
In Cloudflare Pages: Workers & Pages → your Pages project → Custom domains → Set up a domain → `mimiscozycorner.com`.

For the apex domain, Cloudflare requires the domain to be a Cloudflare zone and its nameservers to point to Cloudflare.
